﻿
namespace Placementautomation
{
    partial class stujob
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(stujob));
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(12, 14);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(819, 450);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(122, 95);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(577, 278);
            this.dataGridView1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(721, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 83);
            this.button1.TabIndex = 1;
            this.button1.Text = "back";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label14);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.label23);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Location = new System.Drawing.Point(-320, -111);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(840, 440);
            this.panel5.TabIndex = 10;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(479, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(131, 20);
            this.label14.TabIndex = 0;
            this.label14.Text = "SSLC DETALIS";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.textBox9);
            this.panel6.Controls.Add(this.label15);
            this.panel6.Controls.Add(this.label16);
            this.panel6.Controls.Add(this.label17);
            this.panel6.Location = new System.Drawing.Point(463, 50);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(201, 218);
            this.panel6.TabIndex = 8;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(81, 34);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 23);
            this.textBox9.TabIndex = 9;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(0, 127);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(39, 15);
            this.label15.TabIndex = 2;
            this.label15.Text = "Marks";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(0, 80);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 15);
            this.label16.TabIndex = 1;
            this.label16.Text = "Institution";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(0, 37);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(39, 15);
            this.label17.TabIndex = 0;
            this.label17.Text = "Name";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(254, 27);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(113, 15);
            this.label18.TabIndex = 0;
            this.label18.Text = "PERSONAL  DETALIS";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.textBox10);
            this.panel7.Controls.Add(this.textBox11);
            this.panel7.Controls.Add(this.textBox12);
            this.panel7.Controls.Add(this.textBox13);
            this.panel7.Controls.Add(this.label19);
            this.panel7.Controls.Add(this.label20);
            this.panel7.Controls.Add(this.label21);
            this.panel7.Controls.Add(this.label22);
            this.panel7.Location = new System.Drawing.Point(238, 50);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(219, 218);
            this.panel7.TabIndex = 7;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(110, 174);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 23);
            this.textBox10.TabIndex = 15;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(110, 124);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 23);
            this.textBox11.TabIndex = 14;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(110, 77);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 23);
            this.textBox12.TabIndex = 13;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(110, 30);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 23);
            this.textBox13.TabIndex = 12;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(16, 174);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(36, 15);
            this.label19.TabIndex = 11;
            this.label19.Text = "email";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(16, 127);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 15);
            this.label20.TabIndex = 10;
            this.label20.Text = "Address";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(19, 80);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 15);
            this.label21.TabIndex = 9;
            this.label21.Text = "Phone";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(19, 37);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(39, 15);
            this.label22.TabIndex = 8;
            this.label22.Text = "Name";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(22, 27);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(68, 15);
            this.label23.TabIndex = 0;
            this.label23.Text = "UG DETALIS";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.textBox14);
            this.panel8.Controls.Add(this.textBox15);
            this.panel8.Controls.Add(this.textBox16);
            this.panel8.Controls.Add(this.label24);
            this.panel8.Controls.Add(this.label25);
            this.panel8.Controls.Add(this.label26);
            this.panel8.Location = new System.Drawing.Point(5, 50);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(218, 218);
            this.panel8.TabIndex = 0;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(108, 145);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(101, 23);
            this.textBox14.TabIndex = 6;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(108, 87);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(101, 23);
            this.textBox15.TabIndex = 5;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(108, 23);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(101, 23);
            this.textBox16.TabIndex = 4;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(17, 152);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 15);
            this.label24.TabIndex = 3;
            this.label24.Text = "instituion";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(17, 87);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(39, 15);
            this.label25.TabIndex = 2;
            this.label25.Text = "Marks";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(17, 23);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(44, 15);
            this.label26.TabIndex = 1;
            this.label26.Text = "Course";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label31);
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Controls.Add(this.label35);
            this.panel10.Controls.Add(this.panel12);
            this.panel10.Controls.Add(this.label39);
            this.panel10.Controls.Add(this.panel13);
            this.panel10.Controls.Add(this.label44);
            this.panel10.Controls.Add(this.panel14);
            this.panel10.Location = new System.Drawing.Point(-319, -123);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(859, 460);
            this.panel10.TabIndex = 12;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(700, 31);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(75, 15);
            this.label31.TabIndex = 10;
            this.label31.Text = "PUC DETALIS";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.textBox20);
            this.panel11.Controls.Add(this.label32);
            this.panel11.Controls.Add(this.label33);
            this.panel11.Controls.Add(this.label34);
            this.panel11.Location = new System.Drawing.Point(639, 54);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(220, 214);
            this.panel11.TabIndex = 9;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(111, 30);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 23);
            this.textBox20.TabIndex = 11;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(14, 130);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(39, 15);
            this.label32.TabIndex = 3;
            this.label32.Text = "Marks";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(14, 80);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(61, 15);
            this.label33.TabIndex = 2;
            this.label33.Text = "Institution";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(14, 33);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(41, 15);
            this.label34.TabIndex = 1;
            this.label34.Text = "Regno";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label35.Location = new System.Drawing.Point(479, 27);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(131, 20);
            this.label35.TabIndex = 0;
            this.label35.Text = "SSLC DETALIS";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.textBox21);
            this.panel12.Controls.Add(this.textBox22);
            this.panel12.Controls.Add(this.textBox23);
            this.panel12.Controls.Add(this.label36);
            this.panel12.Controls.Add(this.label37);
            this.panel12.Controls.Add(this.label38);
            this.panel12.Location = new System.Drawing.Point(435, 50);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(198, 218);
            this.panel12.TabIndex = 8;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(92, 127);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 23);
            this.textBox21.TabIndex = 11;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(92, 80);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 23);
            this.textBox22.TabIndex = 10;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(92, 37);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(100, 23);
            this.textBox23.TabIndex = 9;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(0, 127);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(39, 15);
            this.label36.TabIndex = 2;
            this.label36.Text = "Marks";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(0, 80);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(61, 15);
            this.label37.TabIndex = 1;
            this.label37.Text = "Institution";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(0, 37);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(41, 15);
            this.label38.TabIndex = 0;
            this.label38.Text = "Regno";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(254, 27);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(113, 15);
            this.label39.TabIndex = 0;
            this.label39.Text = "PERSONAL  DETALIS";
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.textBox24);
            this.panel13.Controls.Add(this.textBox25);
            this.panel13.Controls.Add(this.textBox26);
            this.panel13.Controls.Add(this.textBox27);
            this.panel13.Controls.Add(this.label40);
            this.panel13.Controls.Add(this.label41);
            this.panel13.Controls.Add(this.label42);
            this.panel13.Controls.Add(this.label43);
            this.panel13.Location = new System.Drawing.Point(220, 50);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(209, 218);
            this.panel13.TabIndex = 7;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(110, 174);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 23);
            this.textBox24.TabIndex = 15;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(110, 124);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(100, 23);
            this.textBox25.TabIndex = 14;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(110, 77);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(100, 23);
            this.textBox26.TabIndex = 13;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(110, 30);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 23);
            this.textBox27.TabIndex = 12;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(16, 174);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(36, 15);
            this.label40.TabIndex = 11;
            this.label40.Text = "email";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(16, 127);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(49, 15);
            this.label41.TabIndex = 10;
            this.label41.Text = "Address";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(19, 80);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(41, 15);
            this.label42.TabIndex = 9;
            this.label42.Text = "Phone";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(19, 37);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(39, 15);
            this.label43.TabIndex = 8;
            this.label43.Text = "Name";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(71, 27);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(68, 15);
            this.label44.TabIndex = 0;
            this.label44.Text = "UG DETALIS";
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.textBox28);
            this.panel14.Controls.Add(this.textBox29);
            this.panel14.Controls.Add(this.textBox30);
            this.panel14.Controls.Add(this.label45);
            this.panel14.Controls.Add(this.label46);
            this.panel14.Controls.Add(this.label47);
            this.panel14.Location = new System.Drawing.Point(5, 50);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(209, 218);
            this.panel14.TabIndex = 0;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(108, 145);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(101, 23);
            this.textBox28.TabIndex = 6;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(108, 87);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(101, 23);
            this.textBox29.TabIndex = 5;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(108, 23);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(101, 23);
            this.textBox30.TabIndex = 4;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(17, 152);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(57, 15);
            this.label45.TabIndex = 3;
            this.label45.Text = "instituion";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(17, 87);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(39, 15);
            this.label46.TabIndex = 2;
            this.label46.Text = "Marks";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(17, 23);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(44, 15);
            this.label47.TabIndex = 1;
            this.label47.Text = "Course";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(321, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 1;
            // 
            // stujob
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(864, 476);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "stujob";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "stujob";
            this.Load += new System.EventHandler(this.stujob_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
    }
}